INSTRUCTIONS:
=============

To run the script, use the command below:
python3 script.py <en/de> <bin/rle/dic/for/dif> <string/int8/int16/int32/int64> <filepath>

An example of this command is provided:
python3 script.py en rle string ../ADM-2020-Assignment-2-data-T-SF-1/l_commitdate-string.csv



PACKAGES:
=========
The following python packages are required to run the script - 

csv
time
sys
pandas
numpy
os



NOTE:
=====

The encoded files are stored in a file called 'out.csv' in the same directory as the script. 

The decoded data is printed to stdout, and also stored in a file called out.csv. In case an output is not seen on stdout, the data will be present on out.csv

